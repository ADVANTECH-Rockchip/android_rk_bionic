#include <sys/cdefs.h>
__FBSDID("$FreeBSD$");

#define type		float
#define	roundit		rintf
#define dtype		long long
#define	fn		llrintf

#include "s_lrint.c"
