int get_value_from_another_lib() {
  return 54321;
}
