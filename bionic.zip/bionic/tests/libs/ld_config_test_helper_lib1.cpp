extern int get_value_from_another_lib();
int get_value_from_lib() {
  return get_value_from_another_lib();
}
