int get_value_from_lib() {
  return 54321;
}
